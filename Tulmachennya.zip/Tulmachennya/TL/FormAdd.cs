using System;
using System.Windows.Forms;

namespace MyDictionary
{
    public partial class FormAdd : Form
    {
        private readonly DictionaryEntryAdder _entryAdder;
        public event Action EntryAdded;
        public FormAdd()
        {
            InitializeComponent();
            _entryAdder = new DictionaryEntryAdder();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (_entryAdder.AddNewEntry(textBoxWord.Text, textBoxMeaning.Text, textBoxTag.Text))
            {
                MessageBox.Show("Слово додано!", "Успіх", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void textBoxTag_TextChanged(object sender, EventArgs e) { }
    }
}