using System.Collections.Generic;
using MyDictionary;

namespace MyDictionary
{
    public static class DictionaryManager
    {
        public static List<DictionaryEntry> Words = new List<DictionaryEntry>();
    }
}