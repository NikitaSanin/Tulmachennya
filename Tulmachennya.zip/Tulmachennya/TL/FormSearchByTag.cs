﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyDictionary;
using Tulmachennya;

namespace Tulmachennya
{
    public partial class FormSearchByTag : Form
    {
        private TagSearchManager tagSearchManager;

        public FormSearchByTag()
        {
            InitializeComponent();
            listViewWords.View = View.Tile;
            listViewWords.FullRowSelect = true;
            listViewWords.MultiSelect = false;
            listViewWords.TileSize = new System.Drawing.Size(200, 30);

            tagSearchManager = new TagSearchManager();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            string tag = textBoxTag.Text.Trim();
            var results = tagSearchManager.SearchWordsByTag(tag);

            tagSearchManager.DisplaySearchResults(results, listViewWords);

            if (results.Count == 0)
            {
                MessageBox.Show("Слів з таким тегом не знайдено.", "Результат", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void buttonView_Click(object sender, EventArgs e)
        {
            if (listViewWords.SelectedItems.Count > 0)
            {
                string selectedWord = listViewWords.SelectedItems[0].Text;
                string details = tagSearchManager.GetWordDetails(selectedWord);

                if (details != null)
                {
                    MessageBox.Show(details, "Перегляд слова", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}