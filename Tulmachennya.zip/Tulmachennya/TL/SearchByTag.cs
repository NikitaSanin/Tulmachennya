﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using MyDictionary;

namespace Tulmachennya
{
    public class TagSearchManager
    {
        public List<string> SearchWordsByTag(string tag)
        {
            return DictionaryManager.Words
                .Where(w => w.Tag.Equals(tag, StringComparison.OrdinalIgnoreCase))
                .Select(w => w.Word)
                .ToList();
        }

        public void DisplaySearchResults(List<string> results, ListView listView)
        {
            listView.Items.Clear();

            foreach (var word in results)
            {
                ListViewItem item = new ListViewItem(word);
                listView.Items.Add(item);
            }
        }

        public string GetWordDetails(string selectedWord)
        {
            var entry = DictionaryManager.Words.FirstOrDefault(w => w.Word == selectedWord);
            return entry != null ? $"Слово: {entry.Word}\nЗначення: {entry.Meaning}" : null;
        }
    }
}