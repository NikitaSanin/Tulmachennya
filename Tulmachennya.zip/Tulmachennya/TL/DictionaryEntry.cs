namespace MyDictionary
{
    public class DictionaryEntry
    {
        public string Word { get; set; }
        public string Meaning { get; set; }
        public string Tag { get; set; }
    }
}