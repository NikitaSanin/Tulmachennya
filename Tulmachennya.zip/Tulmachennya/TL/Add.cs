﻿using System;
using System.Windows.Forms;

namespace MyDictionary
{
    public class DictionaryEntryAdder
    {
        public bool AddNewEntry(string word, string meaning, string tag)
        {
            if (string.IsNullOrWhiteSpace(word) || string.IsNullOrWhiteSpace(meaning))
            {
                MessageBox.Show("Будь ласка, заповніть слово та значення.", "Попередження", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            DictionaryManager.Words.Add(new DictionaryEntry
            {
                Word = word.Trim(),
                Meaning = meaning.Trim(),
                Tag = tag.Trim()
            });

            DictionaryStorage.Save(DictionaryManager.Words);
            return true;
        }
    }
}