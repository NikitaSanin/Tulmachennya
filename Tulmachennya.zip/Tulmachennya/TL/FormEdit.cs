﻿using System;
using System.Windows.Forms;
using MyDictionary;

namespace TL
{
    public partial class FormEdit : Form
    {
        private readonly DictionaryEntryEditor _editor;

        public FormEdit(DictionaryEntry entry)
        {
            InitializeComponent();
            _editor = new DictionaryEntryEditor(entry);
            _editor.LoadEntryData(textBoxWord, textBoxMeaning, textBoxTag);
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (_editor.SaveEntryData(textBoxWord.Text, textBoxMeaning.Text, textBoxTag.Text))
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void word_Click(object sender, EventArgs e) { }
        private void textBoxMeaning_TextChanged(object sender, EventArgs e) { }
        private void textBoxTag_TextChanged(object sender, EventArgs e) { }
        private void textBoxWord_TextChanged(object sender, EventArgs e) { }
    }
}