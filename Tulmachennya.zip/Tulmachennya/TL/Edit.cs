﻿using MyDictionary;
using System;
using System.Windows.Forms;

namespace TL
{
    public class DictionaryEntryEditor
    {
        private DictionaryEntry _entry;

        public DictionaryEntryEditor(DictionaryEntry entry)
        {
            _entry = entry ?? throw new ArgumentNullException(nameof(entry));
        }

        public void LoadEntryData(TextBox wordBox, TextBox meaningBox, TextBox tagBox)
        {
            wordBox.Text = _entry.Word;
            meaningBox.Text = _entry.Meaning;
            tagBox.Text = _entry.Tag;
        }

        public bool SaveEntryData(string word, string meaning, string tag)
        {
            if (string.IsNullOrWhiteSpace(word))
            {
                MessageBox.Show("Слово не може бути порожнім", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            _entry.Word = word.Trim();
            _entry.Meaning = meaning.Trim();
            _entry.Tag = tag.Trim();

            return true;
        }
    }
}